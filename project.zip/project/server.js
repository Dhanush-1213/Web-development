const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/authDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// User Schema
const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

const User = mongoose.model('User', userSchema);

// Cart Item Schema
const cartItemSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    flavor: { type: String, required: true },
    base: String,
    sauce: String,
    toppings: [String],
    quantity: { type: Number, required: true },
    total: { type: Number, required: true },
    createdAt: { type: Date, default: Date.now }
});

const CartItem = mongoose.model('CartItem', cartItemSchema);

// Signup route
app.post('/api/signup', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already registered' });
        }

        // Create new user
        const newUser = new User({ email, password });
        await newUser.save();

        res.status(201).json({ message: 'Signup successful' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Login route
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Find user and check password
        const user = await User.findOne({ email });
        if (!user || user.password !== password) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        res.json({ 
            message: 'Login successful',
            userId: user._id 
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Cart Routes

// Get cart items for a user
app.get('/api/cart/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const cartItems = await CartItem.find({ userId });
        res.json(cartItems);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching cart items' });
    }
});

// Add item to cart
app.post('/api/cart/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const cartItem = new CartItem({
            userId,
            ...req.body
        });
        await cartItem.save();
        res.status(201).json(cartItem);
    } catch (error) {
        res.status(500).json({ message: 'Error adding item to cart' });
    }
});

// Remove item from cart
app.delete('/api/cart/:userId/:itemId', async (req, res) => {
    try {
        const { userId, itemId } = req.params;
        await CartItem.findOneAndDelete({ _id: itemId, userId });
        res.json({ message: 'Item removed from cart' });
    } catch (error) {
        res.status(500).json({ message: 'Error removing item from cart' });
    }
});

// Clear cart
app.delete('/api/cart/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        await CartItem.deleteMany({ userId });
        res.json({ message: 'Cart cleared successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error clearing cart' });
    }
});

// Update cart item quantity
app.put('/api/cart/:userId/:itemId', async (req, res) => {
    try {
        const { userId, itemId } = req.params;
        const { quantity, total } = req.body;
        const updatedItem = await CartItem.findOneAndUpdate(
            { _id: itemId, userId },
            { quantity, total },
            { new: true }
        );
        res.json(updatedItem);
    } catch (error) {
        res.status(500).json({ message: 'Error updating cart item' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});