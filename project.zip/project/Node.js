// server.js (Express Backend)
const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const router = express.Router();

// Proxy configuration for Streamlit
const streamlitProxy = createProxyMiddleware({
  target: 'http://localhost:8501',
  changeOrigin: true,
  ws: true,
  pathRewrite: {
    '^/api/streamlit': '', // Remove the /api/streamlit prefix when forwarding
  },
});

// Add proxy middleware
app.use('/api/streamlit', streamlitProxy);

// API endpoint to check if Streamlit is running
router.get('/streamlit-status', async (req, res) => {
  try {
    const response = await fetch('http://localhost:8501/healthz');
    if (response.ok) {
      res.json({ status: 'running' });
    } else {
      res.json({ status: 'not running' });
    }
  } catch (error) {
    res.json({ status: 'not running' });
  }
});

module.exports = router;