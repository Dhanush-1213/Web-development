// Add this script to customize.html, before the closing body tag

const basePrice = {
    'Small': 4.00,
    'Medium': 5.50,
    'Large': 7.00
};

const toppingPrice = 0.50;  // Price per topping
const saucePrice = 0.75;    // Price per sauce

function calculatePrice() {
    const size = document.querySelector('.size-options .selected')?.textContent || 'Small';
    const toppingsCount = document.querySelectorAll('.options-grid:first-of-type .selected').length;
    const saucesCount = document.querySelectorAll('.options-grid:last-of-type .selected').length;
    
    const total = basePrice[size] + (toppingPrice * toppingsCount) + (saucePrice * saucesCount);
    return total;
}

function updatePrice() {
    const price = calculatePrice();
    document.getElementById('estimatedPrice').textContent = price.toFixed(2);
}

function addToCart() {
    const flavor = document.querySelector('.flavor-container .selected')?.textContent;
    const size = document.querySelector('.size-options .selected')?.textContent;
    const toppings = Array.from(document.querySelectorAll('.options-grid:first-of-type .selected'))
        .map(el => el.textContent);
    const sauces = Array.from(document.querySelectorAll('.options-grid:last-of-type .selected'))
        .map(el => el.textContent);

    if (!flavor || !size) {
        alert('Please select a flavor and size');
        return;
    }

    const item = {
        flavor,
        size,
        toppings,
        sauces,
        price: calculatePrice(),
        quantity: 1
    };

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(item);
    localStorage.setItem('cart', JSON.stringify(cart));
    
    alert('Added to cart!');
}

// Add click handlers to all selectable items
document.querySelectorAll('.flavor-item, .option-item').forEach(item => {
    item.addEventListener('click', function() {
        // For flavor, deselect others in same container
        if (this.classList.contains('flavor-item')) {
            this.parentElement.querySelectorAll('.flavor-item').forEach(el => {
                el.classList.remove('selected');
            });
        }
        // For size, deselect others in same container
        if (this.parentElement.classList.contains('size-options')) {
            this.parentElement.querySelectorAll('.option-item').forEach(el => {
                el.classList.remove('selected');
            });
        }
        this.classList.toggle('selected');
        updatePrice();
    });
});

// Add "Add to Cart" button click handler
document.querySelector('button:contains("Add to Cart")').addEventListener('click', addToCart);

// Initialize price
updatePrice();